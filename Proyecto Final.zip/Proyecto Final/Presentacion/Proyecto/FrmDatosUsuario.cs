﻿using Entidades;
using Logica;
using PresentacionGUI;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace Proyecto
{
    public partial class FrmDatosUsuario : Form
    {
        Cliente Cliente = new Cliente();
        LogicaDBClient logicBDClient = new LogicaDBClient();
        LogicaDatosCliente servicioCliente = new LogicaDatosCliente();
        public FrmDatosUsuario()
        {
            InitializeComponent();
            
            txtTelefono.MaxLength = 10;
        }
        void mantenimiento(String accion)
        {
            Cliente.Id = int.Parse(txtId.Text);
            Cliente.Nombre = txtNombre.Text;
            Cliente.Telefono = txtTelefono.Text;
            var mensaje = servicioCliente.Save(Cliente);
            Cliente.accion = accion;
            String men = logicBDClient.mantenimiento_cliente(Cliente);
            MessageBox.Show(men, "Mensaje", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        void Guardar()
        {
            try
            {
                Cliente cliente = new Cliente();
                cliente.Telefono = txtTelefono.Text;
                cliente.Nombre = txtNombre.Text;
                cliente.Id = int.Parse(txtId.Text);
                var mensaje = servicioCliente.Save(cliente);
                MessageBox.Show(mensaje, "Registro Cliente", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Limpiar(this, groupBox1);
            }
            catch(Exception)
            {

            }
           

        }
        void RegistrarDB()
        {

            if (MessageBox.Show("¿Deseas registrar a " + txtNombre.Text + "?", "Mensaje",
               MessageBoxButtons.YesNo, MessageBoxIcon.Information) == System.Windows.Forms.DialogResult.Yes)
            {
                    mantenimiento("1");
                    Limpiar(this, groupBox1);
            }

        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            RegistrarDB();
            //Guardar();
        }

        private void FormAgregarFamiliar_Load(object sender, EventArgs e)
        {
            OcultarAgregar();

        }

        public void OcultarAgregar()
        {
            if (txtNombre.Text == "")
            {
                btnAgregar.Enabled = false;
            }
            else if (txtNombre.Text != "")
            {
                btnAgregar.Enabled = true;
            }
        }

        private void txtTelefono_KeyPress(object sender, KeyPressEventArgs e)
        {
            SoloNumeros(e);
        }

        public void SoloNumeros(KeyPressEventArgs e)
        {
            if (!(char.IsNumber(e.KeyChar)) && (e.KeyChar != (char)Keys.Back))
            {
                MessageBox.Show("Solo se permiten numeros", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                e.Handled = true;
                return;
            }
        }

        private void txtNombre_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (SoloLetras(e.KeyChar) == false)
            {
                MessageBox.Show("Solo se permiten Letras", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                e.Handled = true;
            }

        }

        public bool SoloLetras(char e)
        {
            if (e >= 65 && e <= 90 || e == 8 || e >= 97 && e <= 122 || e == 32 || e == 165 && e == 164)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            Limpiar(this, groupBox1);
            
        }

        private void Limpiar(Control control, GroupBox group2)
        {
            foreach (var txt in group2.Controls)
            {
                if(txt is TextBox)
                {
                    ((TextBox)txt).Clear();
                }
                else if(txt is DateTimePicker)
                {
                    ((DateTimePicker)txt).Value = DateTime.Now;
                }
            }
        }

        private void txtTelefono_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtId_KeyPress(object sender, KeyPressEventArgs e)
        {
            SoloNumeros(e);
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void l_Click(object sender, EventArgs e)
        {

        }

        private void btnAtras_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}