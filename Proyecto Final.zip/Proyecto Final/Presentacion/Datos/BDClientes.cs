﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using Entidades;
namespace Datos
{
    public class BDClientes
    {
        SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["sql"].ConnectionString);

        public DataTable Listar_Cliente()
        {
            SqlCommand cmd = new SqlCommand("ListarClientes",cn);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            return dt;
        }

        public DataTable Buscar_Clientes(Cliente obj)
        {
            SqlCommand cmd = new SqlCommand("BuscarClientes", cn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Id", obj.Id);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            return dt;
        }
        
        public string Mantenimiento_Clientes(Cliente obj)
        {
            string accion = "";
            SqlCommand cmd = new SqlCommand("MantenimientoClientes", cn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Id", obj.Id);
            cmd.Parameters.AddWithValue("@Nombre", obj.Nombre);
            cmd.Parameters.AddWithValue("@Telefono", obj.Telefono);
            cmd.Parameters.Add("@accion", SqlDbType.VarChar, 50).Value = obj.accion;
            cmd.Parameters["@accion"].Direction = ParameterDirection.InputOutput;
            if (cn.State == ConnectionState.Open) cn.Close();
            cn.Open();
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch(Exception e)
            {
                Console.WriteLine(e.ToString());
            }
            accion = cmd.Parameters["@accion"].Value.ToString();
            cn.Close();
            return accion;
        }

    }
}
