﻿using Entidades;
using Logica;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyecto
{
    public partial class FormEditarVentas : Form
    {
        Factura factura = new Factura();
        LogicaDBVentas LogicDBVentas = new LogicaDBVentas();
        public FormEditarVentas()
        {
            InitializeComponent();
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            EditarDB();
        }
        public void mantenimiento(String accion)
        {
            factura.Id_Compra = int.Parse(txtIdCompra.Text);
            factura.Tipo_Carne = txtTipoCarne.Text;
            factura.Precio = int.Parse(txtPrecio.Text);
            factura.Cantidad = int.Parse(textCantidad.Text);
            factura.Sub_Total = (int.Parse(txtPrecio.Text) * int.Parse(textCantidad.Text));
            factura.accion = accion;
            String men = LogicDBVentas.mantenimiento_ventas(factura);
            MessageBox.Show(men, "Mensaje", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        void EditarDB()
        {
            if (MessageBox.Show("¿Deseas modificar el registro de compra con Id " + txtIdCompra.Text + "?", "Mensaje",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Information) == System.Windows.Forms.DialogResult.Yes)
            {
                mantenimiento("2");
                limpiar();
            }
        }
        void EliminardeDb()
        {
            if (MessageBox.Show("¿Deseas eliminar el registro de compra con Id " + txtIdCompra + "?", "Mensaje",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Information) == System.Windows.Forms.DialogResult.Yes)
            {
                mantenimiento("3");
                limpiar();
            }
        }
        void limpiar()
        {
            txtIdCompra.Text = "";
            txtTipoCarne.Text = "";
            txtPrecio.Text = "";
            textCantidad.Text = "";
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            EliminardeDb();
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
