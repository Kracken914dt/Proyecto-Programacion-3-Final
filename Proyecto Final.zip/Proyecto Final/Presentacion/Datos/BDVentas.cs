﻿using Entidades;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Datos
{
    public class BDVentas
    {
        SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["sql"].ConnectionString);

        public DataTable Listar_Ventas()
        {
            SqlCommand cmd = new SqlCommand("ListarCompras", cn);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            return dt;
        }

        public DataTable Buscar_Ventas(Factura obj)
        {
            SqlCommand cmd = new SqlCommand("BuscarCompras", cn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Id_Compra", obj.Id_Compra);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            return dt;
        }

        public string Mantenimiento_Ventas(Factura obj)
        {
            string accion = "";
            SqlCommand cmd = new SqlCommand("MantenimientoCompras", cn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Id_Compra", obj.Id_Compra);
            cmd.Parameters.AddWithValue("@Tipo_Carne", obj.Tipo_Carne);
            cmd.Parameters.AddWithValue("@Precio", obj.Precio);
            cmd.Parameters.AddWithValue("@Cantidad", obj.Cantidad);
            cmd.Parameters.AddWithValue("@Sub_Total", obj.Sub_Total);
            cmd.Parameters.Add("@accion", SqlDbType.VarChar, 50).Value = obj.accion;
            cmd.Parameters["@accion"].Direction = ParameterDirection.InputOutput;
            if (cn.State == ConnectionState.Open) cn.Close();
            cn.Open();
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }
            accion = cmd.Parameters["@accion"].Value.ToString();
            cn.Close();
            return accion;
        }
    }
}
