﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logica
{
    public interface ControldeDatosCarne<T>
    {
        string Save(T carnee);
        string Delete(T carnee);
        string Edit(T oldcarnee, T Updatecarnee);
        List<T> GetAll();
        bool Exists(T carnee);
    }
}
