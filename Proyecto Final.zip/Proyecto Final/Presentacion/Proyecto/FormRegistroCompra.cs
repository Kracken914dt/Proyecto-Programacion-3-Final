﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using Entidades;
using Logica;
using Proyecto;

namespace PresentacionGUI
{
    public partial class FormRegistroCompra : Form
    {
        FormEditarVentas EditarVentas = new FormEditarVentas();
        LogicaDBVentas LogicDBVentas = new LogicaDBVentas();
        Factura factura = new Factura();
        public FormRegistroCompra()
        {
            InitializeComponent();
            GrillaRegistroCompra.DataSource = LogicDBVentas.listar_Ventas();

        }

        public void EditarDbVentas()
        {
            int fila = GrillaRegistroCompra.CurrentCell.RowIndex;
            EditarVentas.txtIdCompra.Text = GrillaRegistroCompra[0, fila].Value.ToString();
            EditarVentas.txtTipoCarne.Text = GrillaRegistroCompra[1, fila].Value.ToString();
            EditarVentas.txtPrecio.Text = GrillaRegistroCompra[2, fila].Value.ToString();
            EditarVentas.textCantidad.Text = GrillaRegistroCompra[3, fila].Value.ToString();
            EditarVentas.ShowDialog();
            Refrescar();


        }

        public void Refrescar()
        {
            GrillaRegistroCompra.Refresh();
            GrillaRegistroCompra.DataSource = LogicDBVentas.listar_Ventas();

        }

        private void FormTodosFamiliar_Load(object sender, EventArgs e)
        {
            GrillaRegistroCompra.DataSource = LogicDBVentas.listar_Ventas();
        }

        int fila;
        private void GrillaFamiliar_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void GrillaFamiliar_CellClick(object sender, DataGridViewCellEventArgs e)
        {
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            


        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

       


        private void GrillaFamiliar_CellClick_1(object sender, DataGridViewCellEventArgs e)
        {
            fila = e.RowIndex;
        }

        private void GrillaFamiliar_MouseClick(object sender, MouseEventArgs e)
        {
        }
        private void Editar(Object sender, EventArgs e)
        {
           
        }
        private void CleanSelected(Object sender, EventArgs e)
        {
            
        }

        public void MouseClicDerecho(MouseEventArgs e)
        {
            

        }

        private void contextMenuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            

        }

        private void GrillaFamiliar_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            EditarDbVentas();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            EditarDbVentas();
        }

    }
}

