﻿using Entidades;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Logica;
using Proyecto;
using System.Runtime.Remoting;

namespace PresentacionGUI
{
    public partial class FormEditarCliente : Form
    {
        Cliente cliente = new Cliente();
        LogicaDBClient logicBDClient = new LogicaDBClient();
        string tel;
        FrmDatosUsuario DatosUsuario = new FrmDatosUsuario();

        public FormEditarCliente()
        {
            InitializeComponent();
            //txtId.Enabled = false;
            txtTelefono.MaxLength = 10;
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            //Editar();
            EditarDB();
        }
        public void mantenimiento(String accion)
        {
            cliente.Id = Convert.ToInt32(txtId.Text);
            cliente.Nombre = txtNombre.Text;
            cliente.Telefono = txtTelefono.Text;
            cliente.accion = accion;
            String men = logicBDClient.mantenimiento_cliente(cliente);
            MessageBox.Show(men, "Mensaje", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        void EditarDB()
        {
            if (MessageBox.Show("¿Deseas modificar a " + txtNombre.Text + "?", "Mensaje",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Information) == System.Windows.Forms.DialogResult.Yes)
            {
                mantenimiento("2");
                limpiar();
            }
        }
        void EliminardeDb()
        {
            if (MessageBox.Show("¿Deseas eliminar a " + txtId.Text + "?", "Mensaje",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Information) == System.Windows.Forms.DialogResult.Yes)
            {
                mantenimiento("3");
                limpiar();
            }
        }
  
        void limpiar()
        {
            txtId.Text = "";
            txtNombre.Text = "";
            txtTelefono.Text = "";
        }
        public void Telefono()
        {
            tel = txtTelefono.Text;
        }

        private void FormEditarFamiliar_Load(object sender, EventArgs e)
        {
            Telefono();
        }

        private void txtTelefono_KeyPress(object sender, KeyPressEventArgs e)
        {
            DatosUsuario.SoloNumeros(e);
        }

        private void txtNombre_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (DatosUsuario.SoloLetras(e.KeyChar) == false)
            {
                MessageBox.Show("Solo se permiten Letras", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                e.Handled = true;
            }
        }

        private void FormEditarFamiliar_FormClosed(object sender, FormClosedEventArgs e)
        {
            
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dtFecha_ValueChanged(object sender, EventArgs e)
        {

        }

        private void txtId_KeyPress(object sender, KeyPressEventArgs e)
        {
            DatosUsuario.SoloNumeros(e);
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            EliminardeDb();
        }
    }
}
