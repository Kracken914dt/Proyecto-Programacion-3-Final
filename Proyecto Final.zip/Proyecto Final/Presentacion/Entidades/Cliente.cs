﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades
{
    public class Cliente : Persona
    {
        public override string ToString()
        {
            return $"{Id};{Nombre};{Telefono}";
        }

    }
}