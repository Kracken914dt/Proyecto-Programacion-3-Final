create table Recibo_Carnes
(
Id_Compra int,
Tipo_Carne varchar(20),
Precio int,
Cantidad int,
Sub_Total int,
);
go

create proc ListarCompras
as
select * from Recibo_Carnes
go

create proc BuscarCompras
@Id_Compra int
as
select Id_Compra,Tipo_Carne,Precio,Cantidad,Sub_Total from Recibo_Carnes where  Id_Compra like @Id_Compra + '%'
go

create proc MantenimientoCompras
@Id_Compra int,
@Tipo_Carne varchar(20),
@Precio int,
@Cantidad int,
@Sub_Total int,
@accion varchar(50) output
as
if (@accion='1')
begin
	insert into Recibo_Carnes(Id_Compra,Tipo_Carne,Precio,Cantidad,Sub_Total)
	values(@Id_Compra,@Tipo_Carne,@Precio,@Cantidad,@Sub_Total)
	set @accion='Se guardo registro de compra con el c�digo: ' +@Id_Compra
end
else if (@accion='2')
begin
	update Recibo_Carnes set Tipo_Carne=@Tipo_Carne, Precio=@Precio, Cantidad=@Cantidad, Sub_Total=@Sub_Total where Id_Compra=@Id_Compra
	set @accion='Se modifico el registro de compra con el c�digo: ' +@Id_Compra
end
else if (@accion='3')
begin
	delete from Recibo_Carnes where Id_Compra=@Id_Compra
	set @accion='Se borro el registro de compra con c�digo: ' +@Id_Compra
end
go