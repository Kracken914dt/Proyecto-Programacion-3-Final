﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using Datos;
using Entidades;
namespace Logica
{
    public class LogicaDBClient
    {
        BDClientes objDatos = new BDClientes();
        public DataTable listar_Clientes()
        {
            return objDatos.Listar_Cliente();
        }

        public DataTable buscar_Clientes(Cliente client)
        {
            return objDatos.Buscar_Clientes(client);
        }

        public String mantenimiento_cliente(Cliente client)
        {
            return objDatos.Mantenimiento_Clientes(client);
        }
        
    }
}
