﻿using Datos;
using Entidades;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logica
{
    public  class LogicaDBVentas
    {
        BDVentas objDatos = new BDVentas();
        public DataTable listar_Ventas()
        {
            return objDatos.Listar_Ventas();
        }

        public DataTable buscar_Ventas(Factura recibo)
        {
            return objDatos.Buscar_Ventas(recibo);
        }

        public String mantenimiento_ventas(Factura recibo)
        {
            return objDatos.Mantenimiento_Ventas(recibo);
        }
    }
}
