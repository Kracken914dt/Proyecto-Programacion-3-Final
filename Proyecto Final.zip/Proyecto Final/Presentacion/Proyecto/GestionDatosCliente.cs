﻿using Entidades;
using Logica;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Presentacion
{
    public class GestionDatosCliente
    {
        //BUSCAR DATOS CLIENTE

        LogicaDatosCliente servicioCliente = new LogicaDatosCliente();

        public void BuscarCliente()
        {
            var clientes = new Cliente();
            Console.Clear();
            Console.WriteLine("Digite el telefono a consultar cliente: ");
            string tel = Console.ReadLine();
            clientes.Telefono = tel;
            servicioCliente.GetByPhone(tel);
            Console.ReadKey();
            Console.Clear();
        }

      

        //EDITAR DATOS CLIENTE
        public void EditarCliente()
        {
            var Clientes = new Cliente();
            Console.WriteLine("Cliente");
            Console.WriteLine("Telefono del cliente a editar: ");
            string tel = Console.ReadLine();
            var oldTelefono = servicioCliente.GetByPhone(tel);
            Console.WriteLine("Nombre: ");
            string nombre = Console.ReadLine();
            Console.WriteLine("Telefono: ");
            string telefono = Console.ReadLine();
            Console.WriteLine("Fecha de naciemiento: ");
            DateTime fechanacimiento = DateTime.Parse(Console.ReadLine());

            Clientes.Nombre = nombre;
            Clientes.Telefono = telefono;
            servicioCliente.Edit(oldTelefono, Clientes);
            Console.ReadKey();
            Console.Clear();
        }

      

        //ELIMINAR DATOS CLIENTE
        public void EliminarCliente()
        {
            Console.Clear();
            var Clientes = new Cliente();

            Console.WriteLine("Eliminar contacto familiar");
            Console.WriteLine();
            Console.WriteLine("Numero: ");
            string tel = Console.ReadLine();

            Clientes.Telefono = tel;
            servicioCliente.Delete(Clientes);
        }

    

        // AGREGAR DATOS CLIENTE
        public void AgregarCliente()
        {
            var Clientes = new Cliente();

            Console.Clear();
            Console.WriteLine("Cliente");
            Console.WriteLine();
            Console.WriteLine("Nombre: ");
            string nom = Console.ReadLine();

            Console.WriteLine("Telefono: ");
            string tel = Console.ReadLine();

            Console.WriteLine("Fecha nacimiento");

            DateTime fechanacimiento = DateTime.Parse(Console.ReadLine());

            Clientes.Id = new Random().Next(1, 10000);
            Clientes.Nombre = nom;
            Clientes.Telefono = tel;
            servicioCliente.Save(Clientes);

            Console.ReadKey();

        }

        // Motrar todos los datos del cliente
        public void TodosClientes()
        {
            Console.Clear();
            Console.WriteLine("Datos Cliente: ");
            servicioCliente.GetAll();
            Console.WriteLine();
            Console.WriteLine("Contactos Empresariales: ");

            Console.ReadKey();
            Console.Clear();
        }



    }
}
