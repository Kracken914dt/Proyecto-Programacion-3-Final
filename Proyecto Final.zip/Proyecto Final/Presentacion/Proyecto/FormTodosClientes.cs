﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using Entidades;
using Logica;
using Proyecto;

namespace PresentacionGUI
{
    public partial class FormTodosClientes : Form
    {
        Cliente cliente = new Cliente();
        LogicaDBClient logicBDClient = new LogicaDBClient();
        FrmDatosUsuario datesuser = new FrmDatosUsuario();
        FormEditarCliente EditarCliente = new FormEditarCliente();

        public FormTodosClientes()
        {
            InitializeComponent();
            GrillaFamiliar.DataSource = logicBDClient.listar_Clientes();
        }


        private void FormTodosFamiliar_Load(object sender, EventArgs e)
        {
            GrillaFamiliar.DataSource = logicBDClient.listar_Clientes();
        }

        int fila;
        private void GrillaFamiliar_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }

        public void EditarDb()
        {
            int fila = GrillaFamiliar.CurrentCell.RowIndex;
            EditarCliente.txtId.Text = GrillaFamiliar[0, fila].Value.ToString();
            EditarCliente.txtNombre.Text = GrillaFamiliar[1, fila].Value.ToString();
            EditarCliente.txtTelefono.Text = GrillaFamiliar[2, fila].Value.ToString();
            EditarCliente.ShowDialog();
            Refrescar();
        }
        private void GrillaFamiliar_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            EditarDb();

        }
        public void Refrescar()
        {
            GrillaFamiliar.Refresh();
            GrillaFamiliar.DataSource = logicBDClient.listar_Clientes();

        }
    

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            EditarDb();
        }

  
        private void GrillaFamiliar_CellClick_1(object sender, DataGridViewCellEventArgs e)
        {
            fila = e.RowIndex;
        }

        private void GrillaFamiliar_MouseClick(object sender, MouseEventArgs e)
        {

        }
        private void Editar(Object sender, EventArgs e)
        {
            EditarDb();
        }
        private void CleanSelected(Object sender, EventArgs e)
        {
           
        }

        public void MouseClicDerecho(MouseEventArgs e)
        {

        }

        private void contextMenuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            switch (e.ClickedItem.Name)
            {
                case "Editar":

                    break;
                case "Eliminar":

                    break;

            }

        }

        private void GrillaFamiliar_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right && e.RowIndex > -1)
            {
                foreach(DataGridViewRow dr in GrillaFamiliar.SelectedRows)
                {
                    dr.Selected = false;
                }

                GrillaFamiliar.Rows[e.RowIndex].Selected = true;
                ContextMenu cm = new ContextMenu();
                MenuItem mi = new MenuItem();
                mi.Text = "Editar";
                mi.Click += Editar; //metodo al dar cl
                                    //ick
                cm.MenuItems.Add(mi);

                mi = new MenuItem();
                mi.Text = "Eliminar";
                mi.Click += CleanSelected; //metodo al dar click
                cm.MenuItems.Add(mi);

                cm.Show(GrillaFamiliar, new Point(this.Left + GrillaFamiliar.Left + e.X, this.Top + GrillaFamiliar.Top + e.Y));
            }
        }

        private void btnAtras_Click(object sender, EventArgs e)
        {
            this.Close();
        }

   
     
    }
}

