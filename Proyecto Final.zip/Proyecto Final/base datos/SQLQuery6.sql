create database DBClient
go
use DBClient
go

create table Clientes
(
Id int,
Nombre varchar(20),
Telefono varchar(20)
);
go

create proc ListarClientes
as
select * from Clientes
go

create proc BuscarClientes
@Id int
as
select Id,Nombre,Telefono from Clientes where Id like @Id + '%'
go

create proc MantenimientoClientes
@Id int,
@Nombre varchar(20),
@Telefono varchar(20),
@accion varchar(50) output
as
if (@accion='1')
begin
	insert into Clientes(Id,Nombre,Telefono)
	values(@Id,@Nombre,@Telefono)
	set @accion='Se guardo el cliente con el c�digo: ' +@Id
end
else if (@accion='2')
begin
	update Clientes set Nombre=@Nombre, Telefono=@Telefono where Id=@Id
	set @accion='Se modifico el cliente con el c�digo: ' +@Id
end
else if (@accion='3')
begin
	delete from Clientes where Id=@Id
	set @accion='Se borro el c�digo: ' +@Id
end
go