﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using Entidades;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;
using Logica;
using PresentacionGUI;
using Datos;
using System.Security.Cryptography;
using System.Net.Sockets;
using Microsoft.VisualBasic;

namespace Proyecto
{
    public partial class FrmDatosCompra : Form
    {
        LogicaDatosCliente cliente = new LogicaDatosCliente();
        LogicaDBVentas LogicVentas = new LogicaDBVentas();
        Cliente client = new Cliente();
        Factura factura = new Factura();

        private DataTable dt;
        private double total = 0;
        private double subtotal = 0;
        private PrintDocument printDocument1;
        private int idClient = 0;

        public FrmDatosCompra()
        {
            InitializeComponent();

            dt = new DataTable();
            dt.Columns.Add("Id Compra");
            dt.Columns.Add("Tipo Carne");
            dt.Columns.Add("Precio");
            dt.Columns.Add("Cantidad");
            dt.Columns.Add("Sub Total");

            dataGridView1.DataSource = dt;

        }
        
        void mantenimiento(String accion)
        {
            try
            {
                factura.Id_Compra = int.Parse(textIdCompra.Text);
                factura.Tipo_Carne = textBoxTipoCarne.Text;
                factura.Precio = int.Parse(textPrecio.Text);
                factura.Cantidad = int.Parse(textCantidad.Text);
                factura.Sub_Total = (int.Parse(textPrecio.Text) * int.Parse(textCantidad.Text));
                factura.Total = total.ToString();
                factura.accion = accion;
                subtotal = (int.Parse(textPrecio.Text) * int.Parse(textCantidad.Text));
                total = total += subtotal;
                String men = LogicVentas.mantenimiento_ventas(factura);
                MessageBox.Show(men, "Mensaje", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch(Exception e)
            {

            }

        }

        void RegistrarDBVentas()
        {

            if (MessageBox.Show("¿Deseas registrar la venta con codigo " + textIdCompra.Text + "?", "Mensaje",
               MessageBoxButtons.YesNo, MessageBoxIcon.Information) == System.Windows.Forms.DialogResult.Yes)
            {
                mantenimiento("1");
            }

        }

        private void FrmDatosCompra_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
        public void SoloNumeros(KeyPressEventArgs e)
        {
            if (!(char.IsNumber(e.KeyChar)) && (e.KeyChar != (char)Keys.Back))
            {
                MessageBox.Show("Solo se permiten numeros", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                e.Handled = true;
                return;
            }
        }

        public bool SoloLetras(char e)
        {
            if (e >= 65 && e <= 90 || e == 8 || e >= 97 && e <= 122 || e == 32 || e == 165 && e == 164)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        private void buttonCargarLista_Click(object sender, EventArgs e)
        {

            if (textIdCompra.Text != "" && textPrecio.Text != "" && textCantidad.Text != "")
            {

                DataRow row = dt.NewRow();
                row["Id Compra"] = textIdCompra.Text;
                row["Tipo Carne"] = textBoxTipoCarne.Text;
                row["Precio"] = textPrecio.Text;
                row["Cantidad"] = textCantidad.Text;
                row["Sub Total"] = (float.Parse(textPrecio.Text) * float.Parse(textCantidad.Text)).ToString();
                dt.Rows.Add(row);
                subtotal = (float.Parse(textPrecio.Text) * float.Parse(textCantidad.Text));
                total = total += subtotal;
                labelTotalPagar.Text = total.ToString();
                RegistrarDBVentas();
                textIdCompra.Text = textPrecio.Text = textBoxTipoCarne.Text = textCantidad.Text = "";

            }
            
        }

        private void labelTotalPagar_Click(object sender, EventArgs e)
        {

        }

        private void textBoxEfectivo_TextChanged(object sender, EventArgs e)
        {
            try
            {
                labelDevolucion.Text = (float.Parse(textBoxEfectivo.Text) - float.Parse(labelTotalPagar.Text)).ToString();
            }
            catch
            {
                labelDevolucion.Text = 0.ToString();

            }
        }

        private void buttonVerder_Click(object sender, EventArgs e)
        {

            Factura fact = new Factura();
            List<Factura> listFact = new List<Factura>();
            try
            {
                foreach (DataRow row in dt.Rows)
                {
                    fact.Id_Compra = (int)row["Id Compra"];
                    fact.Tipo_Carne = row["Tipo Carne"].ToString();
                    fact.Precio = (int)row["Precio"];
                    fact.Cantidad = (int)row["Cantidad"];
                    fact.Sub_Total = (int)row["Sub Total"];
                    fact.Total = total.ToString();

                    listFact.Add(fact);
                }
            }
            catch(Exception )
            {

            }

            IDdeClientdeCompra();

            printDocument1 = new PrintDocument();
            PrinterSettings ps = new PrinterSettings();
            printDocument1.PrinterSettings = ps;
            printDocument1.PrintPage += printDocument2_PrintPage;
            printDocument1.Print();
        }


        void IDdeClientdeCompra()
        {
            idClient = Convert.ToInt32(Interaction.InputBox("Introduzca el ID del cliente que hizo la compra"));
        }
        
        private void Imprimir_PrintPage(object sender, PrintPageEventArgs e)
        {
            
        }

        private void printDocument2_PrintPage(object sender, PrintPageEventArgs e)
        {
            Font font = new Font("Arial", 14);
            int ancho = 350;
            int y = 20;
            e.Graphics.DrawString("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++", font, Brushes.Black, new RectangleF(0, y += 10, ancho, 20));
            e.Graphics.DrawString("|-------Carniceria Mensch-------|", font, Brushes.Black, new RectangleF(0, y += 20, ancho, 20));
            e.Graphics.DrawString("Direccion: calle Salzburger Vorstadt 15", font, Brushes.Black, new RectangleF(0, y += 20, ancho, 20));
            e.Graphics.DrawString("Telefono: 31456790666" , font, Brushes.Black, new RectangleF(0, y += 20, ancho, 20));
            e.Graphics.DrawString("|-----Datos de Cliente-----|", font, Brushes.Black, new RectangleF(0, y += 30, ancho, 20));

            try
            {
                foreach (var item in cliente.GetAll())
                {
                    if (idClient == item.Id)
                    {
                        e.Graphics.DrawString("ID del cliente: " + item.Id, font, Brushes.Black, new RectangleF(0, y += 20, ancho, 20));
                        e.Graphics.DrawString("Nombre de cliente: " + item.Nombre, font, Brushes.Black, new RectangleF(0, y += 20, ancho, 20));
                        e.Graphics.DrawString("Telefono de cliente: " + item.Telefono, font, Brushes.Black, new RectangleF(0, y += 20, ancho, 20));
                    }

                }
            }
            catch(Exception)
            {

            }

            e.Graphics.DrawString("|---Datos de Compra---|", font, Brushes.Black, new RectangleF(0, y += 30, ancho, 20));
            foreach (DataRow row in dt.Rows)
            {
                e.Graphics.DrawString("Id de compra: " + row["Id Compra"].ToString() , font, Brushes.Black, new RectangleF(0, y += 20, ancho, 20));
                e.Graphics.DrawString("Tipo de carne: " + row["Tipo Carne"].ToString(), font, Brushes.Black, new RectangleF(0, y += 20, ancho, 20));
                e.Graphics.DrawString("Precio: " + row["Precio"].ToString(), font, Brushes.Black, new RectangleF(0, y += 20, ancho, 20));
                e.Graphics.DrawString("Cantidad: " + row["Cantidad"].ToString(), font, Brushes.Black, new RectangleF(0, y += 20, ancho, 20));
            }
            e.Graphics.DrawString("Sub Total: $" + subtotal, font, Brushes.Black, new RectangleF(0, y += 20, ancho, 20));
            e.Graphics.DrawString("|--Total---| $" + total, font, Brushes.Black, new RectangleF(0, y += 20, ancho, 20));
            e.Graphics.DrawString("-----Gracias por su compra------ ", font, Brushes.Black, new RectangleF(0, y += 40, ancho, 20));
            e.Graphics.DrawString("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++", font, Brushes.Black, new RectangleF(0, y += 30, ancho, 20));
        }

        private void textIdCompra_KeyPress(object sender, KeyPressEventArgs e)
        {
            SoloNumeros(e);
        }

        private void textPrecio_KeyPress(object sender, KeyPressEventArgs e)
        {
            SoloNumeros(e);
        }

        private void textCantidad_KeyPress(object sender, KeyPressEventArgs e)
        {
            SoloNumeros(e);
        }

        private void textBoxEfectivo_KeyPress(object sender, KeyPressEventArgs e)
        {
            SoloNumeros(e);
        }

        private void textTipoCarne_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (SoloLetras(e.KeyChar) == false)
            {
                MessageBox.Show("Solo se permiten Letras", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                e.Handled = true;
            }
        }
        private void hideSubmenu()
        {
            if (panel1.Visible == true)
                panel1.Visible = false;
            if (panel2.Visible == true)
                panel2.Visible = false;

        }
        private void button_Registro_Click(object sender, EventArgs e)
        {
            var Registrocompra = new FormRegistroCompra();
            Registrocompra.ShowDialog();
            dataGridView1.DataSource = LogicVentas.listar_Ventas();
            hideSubmenu();

        }

        private void btnAtras_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

